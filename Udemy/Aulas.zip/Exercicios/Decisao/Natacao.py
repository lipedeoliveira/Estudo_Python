idade = int(input("Insira sua idade: "))

if (idade >=5 and idade<7):
    print("Voce se classifica como Infantil A")

elif (idade>=8 and idade<=10):
    print("Voce se classificia como Infantil B")

elif (idade>=11 and idade<=13):
    print("Voce se classifica como Infantil C")