identificacao = input("Insira seu id: ")
senha_inserida = input("Insira sua senha de usuário: ")

if senha_inserida != '123456':
    print("Senha incorreta")

else:
    print("Senha correta")