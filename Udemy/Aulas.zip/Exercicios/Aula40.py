lista = ['Maria','Joao','Pedro','Mateus','Rebeca']
i = 0
for nome in lista:
    print(f'O nome -> :{nome} está no indice {i}')
    i+=1