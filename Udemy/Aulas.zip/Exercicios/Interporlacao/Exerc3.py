nome = input("Insira seu Nome: ")
idade = int(input("Insira sua idade: "))
profissao= input("Insira sua profissao: ")

imprimir="Olá, %s, você tem %d e trabalha na profissão de: %s"%(nome,idade,profissao)

print(imprimir)