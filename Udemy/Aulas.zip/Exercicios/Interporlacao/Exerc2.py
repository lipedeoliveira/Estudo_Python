numero1=float(input("Insira um Número para poder somar: "))
numero2=float(input("Insira outro Número para poder somar: "))

numero3=numero1+numero2

print("A soma do numero %.2f com o número %.2f resulta em , %.2f"%(numero1,numero2,numero3))
