nome = input("Insira seu nome: ")
idade = int(input("Insira sua idade: "))

print("Olá, %s , você tem %d"%(nome,idade))