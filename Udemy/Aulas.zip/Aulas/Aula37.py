"""
Listas em Python == comparável ao vetor do java
Tipo list - mutável
Suporta vários valores de qualquer tipo
Conhecimentos utilizáveis - indices e fatiamentos   

Métodos úteis: append,insert,pop, del, clear, extend +


"""


# lista = list() - Serve para criar listas, contudo não é o mais comum

lista = [123,True,"Teste",1.2,[]]

lista[-3] = "Arroz"

print(lista[-3], type(lista))