"""
for in com listas

"""
lista = ['Joao','Maria','Pedro']

for letraa in lista:
    print(letraa)