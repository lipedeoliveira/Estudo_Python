#Cálculo de imc 
nome="Felipe"
peso=61.5
altura=1.80
imc=peso/altura**2
print(nome,"tem ",peso,"kg, possui ",altura," metros de altura e seu IMC é igual a ",imc)