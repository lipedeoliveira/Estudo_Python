adição = 10+10
print("adição", adição)

subtração = 10-5
print("Subtracao",subtração)

multiplicação = 10*10
print("Multiplicacao", multiplicação)

divisao=10/2 # float
print("divisao",divisao)

divisao_inteira=10//2
print("divisao inteira", divisao_inteira)

exponenciacao = 10**2
print("Exponenciacao",exponenciacao)

modulo = 55%2 #Resto da divisao
print("Modulo",modulo)
print(10%2==0)