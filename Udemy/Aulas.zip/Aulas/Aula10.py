concatencao="A"+"B"+"C"
print(concatencao)

a_dez_vezes="A"*10
print(a_dez_vezes)
felipe_tres_vezes=3*"felipe"
print(felipe_tres_vezes)

nm=int(input("Digite seu nome"))
print(type(nm))