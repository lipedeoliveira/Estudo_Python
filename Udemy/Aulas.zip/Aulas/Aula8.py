#Exercicio

nome = "Felipe"
sobrenome = "Oliveira"
idade = 16
ano_nascimento = 2007
maior_de_idade = idade>=18
altura = 1.80

print( "Nome:",nome)
print( "Sobrenome:",sobrenome)
print( "Idade:",idade)
print( "Ano de nascimento:",ano_nascimento)
print( "É maior de idade ?:",maior_de_idade)
print( "Altura em metros:",altura)
