#Tipos int e flot
"""
int = número inteiro
o tipo int representa qualquer número positivo ou negativo.
Sem sinal algum, o int é considerado positivo
"""
print(10)
print(-10)

#float = número com ponto flutuante
#O tipo float representa qualquer número positivo ou negativo que possua o ponto flutuante
#Float sem sinal é considerado positivo
print(1.1,1.9)
print(0.0,-1.9)

#A função type mostra o tipo que o Python inferiu ao valor
print(type("batata"))
print(type(1))
print(type(-1.0),type(1.0),type(0.04))
print(type(False))

#Tudo em Python é um objeto


