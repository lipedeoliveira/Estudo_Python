"""
Interpretador de Python

python mod.py (executa o mod)
python -u (unbuffered)
python -m mod (lib mod como script)
python -c 'cmd'(comando)
python -i mod.py (interativo)

"""