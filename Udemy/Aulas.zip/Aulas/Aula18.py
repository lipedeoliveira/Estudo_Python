"""
Operadores in e not in
Strings sao iteraveis

0 1 2 3 4 5
 
F E L I P E 

-6-5-4-3-2-1

"""

nome = 'felipe'



# segue a mesma lógica do vetor em Java, só que nesse caso
#não se declara um vetor, mas se acessa o dado que está em determinada posição

print(nome[2])
print(nome[-4])

#exibe a letra esta dentro da variavel
#no caso, a funcao 'in' serve para fazer
#essa verificacao

print(15*'-')

print('i' in nome)
print('lipe' not in nome)