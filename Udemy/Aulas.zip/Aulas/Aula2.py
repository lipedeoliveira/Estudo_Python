# CRLF (Carriage Return Line Feed) = quebra de linha especifica do Windows, e é representada por \r (return) e \n (line feed)
print(123, 456, sep=" - " , end=" %%")
print(123, 456, sep=" - " , end=" %%\n")
print(789, 101112, sep=" - ", end=" ")
