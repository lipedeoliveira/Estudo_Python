texto = 'Python'

#Para cada letra no iterável
#O for sabe o começo e o fim do iterável 
for letra in texto:
    #Exibe indice por indice
    print(letra)