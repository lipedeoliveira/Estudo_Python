"""
#for não depende de range, e vice versa, mas são comuns juntos

For + range
range -> range(start,stop,step)
         range(começo,fim,'pulo')

"""

numeros = range(0,11,2)

for numero in numeros:
    print(numero)