package Aulas;
import javax.swing.*;

public class teste  {
     public static void main(String[]args)  {
        System.out.println("Hello World");
        for(int i = 0;i<=10;i++) {
        JOptionPane.showMessageDialog(null,"Este é o indice: -> "+i);
        }
        System.out.println("Saiu do Loop");
    }
}