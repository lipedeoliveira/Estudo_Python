'''
print serve para exibir algo na tela/terminal
'''
# o '#' serve para criar um comentário de linha única
print("Ola mundo")
print(1+1)

"""
Usar tres aspas, serve para criar uma Docstring, mas e usada em algumas vezes como comentario, porem
o Python ainda le essas linhas
"""