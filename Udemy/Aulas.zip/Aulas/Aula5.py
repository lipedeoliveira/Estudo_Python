# Tipo de dado bool ( boolean)
# Ao questionar algo em um programa, só existem duas 
# respotas possíveis:sim(True) ou não (False).
# Existem varios operadores para "questionar",
# dentre eles o ==, que é um operador lógico que serve
# para questionar se um valor é igual a outro

print(10==20) #False = Não (falso)
print(10==10) #True = sim (verdadeiro)
print(type(10==10))
print(type(True))
