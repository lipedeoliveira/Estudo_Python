nm=input("Qual seu nome ?  ")
print(f"O seu nome é {nm}")

n1=input("informe um numero: ")
n2=input("informe um outro numero: ")

n1_int= int(n1)
n2_int= int(n2)

print(f"A soma dos numeros resulta em {n1_int+n2_int}")