"""
Python = Linguagem de programação
Tipo de tipagem = Dinâmica ( O Python reconhece o tipo de informação que está sendo passada) / Forte
str =string = texto
String são textos que estão dentro de aspas
"""
#Aspas duplas
print("Ola mundo")
#Aspas simples
print('Ola mundo')

#Caso queira se colocar um texto dentro de aspas,use o caracter de Escape = \
print("Batata \"ola\"")
#Caso haja a necessidade de que o caracter de Escape apareça, basta usar r
print(r"Batata \"ola\"")
