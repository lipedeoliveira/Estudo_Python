# Conversão de tipos de dados,
# coerção, type convertion, typecasting,
# coercion é o ato de converter um tipo em 
# outro tipos imutáveis e primitivos:str,int,
# float,bool

#Polimorfismo = usar o mesmo operador para fazer coisas diferentes
#convertendo 
print(type(int("1")))
print(int("1"),type(int("1")))
print(int("1")+1)

#Float + Int = Float
print(bool(" ")) #String equivale a True
print(bool("")) #String vazia é reconhecida como False
print(str(11)+"a")
