#;f string

nome="felipe"
idade=16
altura=1.82
linha0=f'{nome} tem {idade} anos de idade'
linha1=f"Usando :.(numero)f se pode definir quantas casas decimais serao mostradas, exemplo: {altura:.1f}"
print(linha0)
print(linha1)
print(f"Qual meu nome ? {nome.upper( )}")